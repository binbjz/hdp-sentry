DROP DATABASE encrypt_db4alter;
DROP DATABASE encrypt_db4data;
DROP DATABASE encrypt_db4drop_cascade;
DROP DATABASE encrypt_db4msck;
DROP DATABASE encrypt_db4func cascade;
DROP DATABASE encrypt_db4props;
DROP DATABASE encrypt_db4tbl;
