CREATE DATABASE encrypt_db4alter;
CREATE DATABASE encrypt_db4data;
CREATE DATABASE encrypt_db4drop_cascade;
CREATE DATABASE encrypt_db4msck;
CREATE DATABASE encrypt_db4func;
CREATE DATABASE encrypt_db4props;
CREATE DATABASE encrypt_db4tbl;
