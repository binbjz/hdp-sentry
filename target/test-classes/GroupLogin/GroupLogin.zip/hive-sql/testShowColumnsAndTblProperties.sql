USE mart_waimai;

SHOW TBLPROPERTIES mart_waimai.dim_ad_cpc_activity;
SHOW COLUMNS IN mart_waimai.dim_ad_cpc_activity;
SHOW COLUMNS FROM mart_waimai.dim_ad_cpc_activity;
