USE default;

CREATE DATABASE mart_waimai WITH DBPROPERTIES ('creator' = 'hadoop-QA', 'date' = '2017-10-02');
CREATE DATABASE mart_waimai_new WITH DBPROPERTIES ('creator' = 'hadoop-QA', 'date' = '2017-10-02');
CREATE DATABASE mart_wmorg WITH DBPROPERTIES ('creator' = 'hadoop-QA', 'date' = '2017-10-02');
CREATE DATABASE origin_waimai WITH DBPROPERTIES ('creator' = 'hadoop-QA', 'date' = '2017-10-02');

CREATE DATABASE ba_ups;
CREATE DATABASE dim;
CREATE DATABASE dw;
CREATE DATABASE mart_waimai_crm;
CREATE DATABASE origindb;
CREATE DATABASE origindb_delta;
CREATE DATABASE origin_dianping;
