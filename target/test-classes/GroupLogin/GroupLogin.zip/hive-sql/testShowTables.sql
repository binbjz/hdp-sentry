USE default;
SHOW TABLES;

USE ba_ups;
SHOW TABLES;

USE dim;
SHOW TABLES;

USE dw;
SHOW TABLES;

USE mart_waimai;
SHOW TABLES;

USE mart_waimai_crm;
SHOW TABLES;

USE mart_wmorg;
SHOW TABLES;

USE origin_waimai;
SHOW TABLES;

USE origindb;
SHOW TABLES;

USE origindb_delta;
SHOW TABLES;

USE origin_dianping;
SHOW TABLES;
