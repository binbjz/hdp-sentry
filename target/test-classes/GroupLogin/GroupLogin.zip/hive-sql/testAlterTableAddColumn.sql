USE mart_waimai;

ALTER TABLE test_add_columns ADD COLUMNS (id STRING);
DESCRIBE test_add_columns;
