USE default;

SHOW DATABASES LIKE 'origin_waimai';
SHOW DATABASES LIKE 'origin_waimai_crm';
DROP DATABASE origin_waimai CASCADE;
DROP DATABASE origin_waimai_crm CASCADE;
SHOW DATABASES LIKE 'origin_waimai';
SHOW DATABASES LIKE 'origin_waimai_crm';
