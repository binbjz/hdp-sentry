USE default;

SHOW DATABASES LIKE 'origin_waimai';
DROP DATABASE origin_waimai;
DROP DATABASE dim;
SHOW DATABASES LIKE 'origin_waimai';
